# Riwaaz — Premium Fashion E-Commerce Platform

Culture · Tradition · Royalty

A full-stack, production-ready e-commerce platform.

- **Frontend:** Next.js 15 (App Router), React, Tailwind CSS
- **Backend:** Node.js, Express.js, MongoDB (Mongoose)
- **Auth:** JWT (separate customer + admin roles)
- **Media:** Cloudinary
- **Payments:** Razorpay + Cash on Delivery

---

## 1. Project Structure

```
riwaaz/
├── client/                  # Next.js 15 frontend (customer site + admin panel)
│   ├── app/
│   │   ├── (shop)/          # Public storefront routes
│   │   │   ├── page.tsx             # Homepage
│   │   │   ├── product/[slug]/      # Product detail page
│   │   │   ├── category/[slug]/     # Category listing + filters
│   │   │   ├── cart/
│   │   │   ├── checkout/
│   │   │   ├── order-success/[id]/
│   │   │   ├── wishlist/
│   │   │   ├── account/
│   │   │   │   ├── login/
│   │   │   │   ├── signup/
│   │   │   │   └── forgot-password/
│   │   ├── admin/                   # Hidden admin panel (NOT linked from storefront nav)
│   │   │   ├── login/                       # Separate admin login
│   │   │   ├── dashboard/
│   │   │   ├── products/
│   │   │   ├── categories/
│   │   │   ├── orders/
│   │   │   ├── customers/
│   │   │   ├── homepage-editor/
│   │   │   └── settings/
│   │   ├── layout.tsx
│   │   └── globals.css
│   ├── components/
│   ├── lib/                 # api client, auth helpers, hooks
│   ├── public/
│   ├── next.config.js
│   ├── tailwind.config.js
│   └── package.json
│
├── server/                  # Express API
│   ├── config/
│   │   ├── db.js            # MongoDB connection
│   │   └── cloudinary.js
│   ├── models/
│   │   ├── User.js          # customers
│   │   ├── Admin.js
│   │   ├── Product.js
│   │   ├── Category.js
│   │   ├── Order.js
│   │   ├── Wishlist.js
│   │   └── HomepageContent.js
│   ├── controllers/
│   ├── routes/
│   ├── middleware/
│   │   ├── auth.js          # verifyToken
│   │   ├── isAdmin.js       # role guard
│   │   ├── rateLimiter.js
│   │   └── errorHandler.js
│   ├── utils/
│   ├── server.js            # entry point
│   └── package.json
│
└── README.md
```

**Why the admin panel is hidden:** it lives at `/admin/*`, is never linked from the storefront header/footer/sitemap, is blocked from search indexing (`robots: noindex` + `disallow` in `robots.txt`), and every `/admin` route (except `/admin/login`) is wrapped in a server-side check for a valid **admin-role JWT** — a customer JWT is rejected even if guessed/typed directly.

---

## 2. Prerequisites

- Node.js 20+
- A MongoDB Atlas cluster (free tier is fine to start)
- A Cloudinary account (free tier)
- A Razorpay account (test mode keys to start)
- npm or pnpm

---

## 3. Environment Variables

### `server/.env` (copy from `server/.env.example`)
```
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:3000

MONGO_URI=your_mongodb_atlas_connection_string

JWT_SECRET=replace_with_a_long_random_string
JWT_EXPIRES_IN=7d
ADMIN_JWT_SECRET=replace_with_a_different_long_random_string

CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

RAZORPAY_KEY_ID=your_key_id
RAZORPAY_KEY_SECRET=your_key_secret

RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX=200
```

### `client/.env.local` (copy from `client/.env.example`)
```
NEXT_PUBLIC_API_URL=http://localhost:5000/api
NEXT_PUBLIC_RAZORPAY_KEY_ID=your_key_id
NEXT_PUBLIC_WHATSAPP_NUMBER=910000000000
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

> Never commit real `.env` files. Only `.env.example` should be in version control.

---

## 4. Local Setup

```bash
# 1. Install server dependencies
cd server
npm install
npm run seed      # creates the first admin account + sample categories
npm run dev        # starts Express on http://localhost:5000

# 2. In a new terminal, install client dependencies
cd client
npm install
npm run dev        # starts Next.js on http://localhost:3000
```

Visit:
- Storefront: http://localhost:3000
- Admin panel: http://localhost:3000/admin/login (credentials printed by `npm run seed`)

---

## 5. Creating the First Admin

Admin accounts are **never** created through public signup. Run:

```bash
cd server
npm run seed
```

This creates one Admin document directly in MongoDB with a hashed password, and prints the login email/password once to your terminal. Change the password immediately after first login (Settings → Change Password).

---

## 6. Deployment

**Recommended stack:**
- Frontend (`client/`) → **Vercel** (native Next.js support, free tier)
- Backend (`server/`) → **Render** or **Railway** (Node hosting, free/low-cost tier)
- Database → **MongoDB Atlas** (managed, free M0 tier)
- Images → **Cloudinary** (already cloud-hosted)

**Steps:**
1. Push this repo to GitHub (two options: monorepo with root directory settings per-service, or split into two repos).
2. On Render/Railway: create a new Web Service pointing at `server/`, set the build command `npm install`, start command `npm start`, and paste all `server/.env` values into the dashboard's environment variables.
3. On Vercel: import the repo, set root directory to `client/`, and paste all `client/.env.local` values into Vercel's Environment Variables settings.
4. Update `CLIENT_URL` in the backend env to your live Vercel URL (for CORS), and `NEXT_PUBLIC_API_URL` in the frontend env to your live backend URL.
5. In Razorpay dashboard, switch from test keys to live keys once you're ready to accept real payments, and complete their KYC/activation flow.
6. Add your production domain to MongoDB Atlas's Network Access allow-list and to Cloudinary's allowed origins if using unsigned uploads (we use signed uploads from the server, so this is optional).

---

## 7. Security Notes

- Passwords hashed with bcrypt (12 salt rounds) for both customers and admins.
- Separate JWT secrets for customer tokens and admin tokens — an admin token cannot be forged from a leaked customer secret and vice versa.
- Admin routes protected server-side (middleware) **and** re-checked in the Next.js middleware layer before rendering `/admin/*` pages — a customer cannot reach the admin UI even by URL.
- All input validated (Joi/Zod) and sanitized before hitting MongoDB (prevents NoSQL injection).
- express-rate-limit applied globally and more strictly on `/api/auth/*` routes.
- Cloudinary uploads are signed server-side; the API secret never reaches the browser.
- Razorpay payment verification is done server-side via signature check — the client cannot mark an order "paid" on its own.

---

## 8. Build Order (this scaffold is stage 1 of 4)

1. ✅ Scaffold + setup guide (this stage)
2. Backend API — models, auth, product/category/order CRUD, Cloudinary, Razorpay
3. Storefront pages — product detail, cart, checkout, account, order success
4. Admin panel — dashboard, product/category/order/customer management, homepage editor, settings
