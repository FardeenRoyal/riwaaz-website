// The full homepage design (hero slider, categories, product rows, promo
// banner, newsletter, footer, WhatsApp button) was delivered separately as
// an interactive prototype — port its JSX/markup into this file, wiring the
// data (categories, featured/new/trending/sale products, hero slides) to
// real API calls against `${NEXT_PUBLIC_API_URL}/homepage` and
// `${NEXT_PUBLIC_API_URL}/products` instead of the static demo arrays.
//
// Built in stage 3 (storefront pages).

export default function HomePage() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-ivory text-ink px-6 text-center">
      <div>
        <p className="text-xs tracking-[0.3em] text-gold mb-3">RIWAAZ</p>
        <h1 className="font-display text-2xl mb-2">Homepage</h1>
        <p className="text-sm text-black/50 max-w-sm">
          Wire up the delivered homepage prototype here, backed by live data
          from the API instead of static demo arrays.
        </p>
      </div>
    </main>
  );
}
