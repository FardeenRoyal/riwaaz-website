export default function Page() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-ivory text-ink px-6 text-center">
      <div>
        <p className="text-xs tracking-[0.3em] text-gold mb-3">RIWAAZ</p>
        <h1 className="font-display text-2xl mb-2">Category Management</h1>
        <p className="text-sm text-black/50">Built in stage 4 of the project plan.</p>
      </div>
    </main>
  );
}
