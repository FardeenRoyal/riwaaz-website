import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: {
    default: "Riwaaz — Culture, Tradition, Royalty",
    template: "%s | Riwaaz",
  },
  description:
    "Riwaaz — premium heritage fashion. Handcrafted sarees, kurta sets, lehengas and sherwanis, rooted in Indian tradition.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  robots: { index: true, follow: true }, // overridden to noindex for /admin/* via next.config.js headers
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
