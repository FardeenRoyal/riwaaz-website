import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

// Runs before any /admin/* page renders. Checks for an admin session cookie
// (set on successful POST /api/admin/auth/login) and redirects to the admin
// login screen if it's missing. This is a UX-layer guard — the real security
// boundary is the `protectAdmin` middleware on the Express API, which
// re-verifies the admin JWT (signed with ADMIN_JWT_SECRET) on every request.
export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (pathname.startsWith("/admin") && pathname !== "/admin/login") {
    const adminToken = req.cookies.get("riwaaz_admin_token")?.value;

    if (!adminToken) {
      const loginUrl = new URL("/admin/login", req.url);
      return NextResponse.redirect(loginUrl);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*"],
};
