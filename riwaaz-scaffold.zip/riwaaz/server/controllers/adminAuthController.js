const jwt = require("jsonwebtoken");
const asyncHandler = require("express-async-handler");
const Admin = require("../models/Admin");

const signAdminToken = (id) =>
  jwt.sign({ id, role: "admin" }, process.env.ADMIN_JWT_SECRET, {
    expiresIn: process.env.ADMIN_JWT_EXPIRES_IN || "1d",
  });

// @route  POST /api/admin/auth/login
// There is intentionally NO /signup route here. Admin accounts are created
// only via `npm run seed` or by a superadmin from the Settings panel.
const adminLogin = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required" });
  }

  const admin = await Admin.findOne({ email }).select("+password");
  if (!admin || !(await admin.comparePassword(password))) {
    return res.status(401).json({ message: "Invalid credentials" });
  }
  if (!admin.isActive) {
    return res.status(403).json({ message: "This admin account has been disabled" });
  }

  res.json({
    token: signAdminToken(admin._id),
    admin: { id: admin._id, name: admin.name, email: admin.email, role: admin.role },
  });
});

module.exports = { adminLogin };
