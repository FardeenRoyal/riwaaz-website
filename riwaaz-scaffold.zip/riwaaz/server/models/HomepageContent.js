const mongoose = require("mongoose");

const slideSchema = new mongoose.Schema(
  {
    image: {
      url: { type: String, required: true },
      publicId: { type: String, required: true },
    },
    eyebrow: { type: String },
    title: { type: String, required: true },
    subtitle: { type: String },
    buttonText: { type: String, default: "Shop Now" },
    buttonLink: { type: String, default: "/" },
    displayOrder: { type: Number, default: 0 },
    isActive: { type: Boolean, default: true },
  },
  { _id: true }
);

const promoBannerSchema = new mongoose.Schema(
  {
    image: {
      url: { type: String },
      publicId: { type: String },
    },
    eyebrow: { type: String },
    title: { type: String },
    buttonText: { type: String },
    buttonLink: { type: String },
    isActive: { type: Boolean, default: true },
  },
  { _id: false }
);

// Singleton document — there is always exactly one HomepageContent record.
// The admin "Homepage Editor" reads and writes this single document.
const homepageContentSchema = new mongoose.Schema(
  {
    heroSlides: [slideSchema],
    promoBanner: promoBannerSchema,

    featuredProductIds: [{ type: mongoose.Schema.Types.ObjectId, ref: "Product" }],
    // newArrivals / trending / sale are queried dynamically by product flags
    // (isNewArrival / isTrending / salePrice != null), so no manual list needed —
    // but admin can override section titles/subtitles below without touching code.

    sectionTitles: {
      featured: { type: String, default: "Featured Products" },
      newArrivals: { type: String, default: "New Arrivals" },
      trending: { type: String, default: "Trending Collection" },
      sale: { type: String, default: "Sale" },
    },

    newsletterHeading: { type: String, default: "Join the Riwaaz Circle" },
    newsletterSubtext: {
      type: String,
      default: "Early access to new drops, festive edits, and private sales.",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("HomepageContent", homepageContentSchema);
