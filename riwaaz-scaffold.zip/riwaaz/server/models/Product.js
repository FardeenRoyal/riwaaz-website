const mongoose = require("mongoose");

const sizeStockSchema = new mongoose.Schema(
  {
    size: { type: String, required: true }, // e.g. "S", "M", "L", "XL", "Free Size"
    stock: { type: Number, required: true, default: 0, min: 0 },
  },
  { _id: false }
);

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, lowercase: true },
    description: { type: String, required: true },
    category: { type: mongoose.Schema.Types.ObjectId, ref: "Category", required: true },

    price: { type: Number, required: true, min: 0 },
    salePrice: { type: Number, min: 0, default: null }, // null = not on sale

    images: [
      {
        url: { type: String, required: true },
        publicId: { type: String, required: true },
      },
    ],

    sizes: [sizeStockSchema],
    sizeGuideImage: {
      url: { type: String },
      publicId: { type: String },
    },

    totalStock: { type: Number, default: 0 }, // derived sum of sizes[].stock, kept for fast queries
    status: {
      type: String,
      enum: ["active", "out_of_stock", "draft"],
      default: "active",
    },

    // Homepage placement flags — admin toggles these, storefront queries by flag
    isFeatured: { type: Boolean, default: false },
    isNewArrival: { type: Boolean, default: false },
    isTrending: { type: Boolean, default: false },

    ratingAverage: { type: Number, default: 0 },
    ratingCount: { type: Number, default: 0 },

    tags: [{ type: String }],
  },
  { timestamps: true }
);

productSchema.index({ name: "text", description: "text", tags: "text" });
productSchema.index({ category: 1, status: 1 });

productSchema.pre("save", function (next) {
  this.totalStock = this.sizes.reduce((sum, s) => sum + s.stock, 0);
  if (this.totalStock === 0 && this.status === "active") {
    this.status = "out_of_stock";
  }
  next();
});

module.exports = mongoose.model("Product", productSchema);
