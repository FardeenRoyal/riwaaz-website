const mongoose = require("mongoose");

// Singleton document — one Settings record for the whole site.
const settingsSchema = new mongoose.Schema(
  {
    siteName: { type: String, default: "Riwaaz" },
    logo: {
      url: { type: String },
      publicId: { type: String },
    },
    favicon: {
      url: { type: String },
      publicId: { type: String },
    },
    whatsappNumber: { type: String, default: "" },
    contactEmail: { type: String, default: "" },
    contactPhone: { type: String, default: "" },
    contactAddress: { type: String, default: "" },
    socialLinks: {
      instagram: { type: String, default: "" },
      facebook: { type: String, default: "" },
      pinterest: { type: String, default: "" },
      youtube: { type: String, default: "" },
    },
    freeShippingThreshold: { type: Number, default: 2999 },
    codEnabled: { type: Boolean, default: true },
    razorpayEnabled: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Settings", settingsSchema);
