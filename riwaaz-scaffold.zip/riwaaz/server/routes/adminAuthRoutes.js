const express = require("express");
const router = express.Router();
const { adminLogin } = require("../controllers/adminAuthController");

// Only a login route is exposed publicly. Everything else under /api/admin/*
// requires the protectAdmin middleware (see middleware/isAdmin.js).
router.post("/login", adminLogin);

module.exports = router;
