const express = require("express");
const router = express.Router();


// ---------------------------------------------------------------
// Category routes — full CRUD implemented in stage 2 (Backend API build).
// Wired here now so server.js boots cleanly and the route table is final.
// ---------------------------------------------------------------

router.get("/", (req, res) => {
  res.json({ message: "Category route placeholder — implemented in stage 2" });
});

module.exports = router;
