const express = require("express");
const router = express.Router();


// ---------------------------------------------------------------
// Homepage content routes — full CRUD implemented in stage 2 (Backend API build).
// Wired here now so server.js boots cleanly and the route table is final.
// ---------------------------------------------------------------

router.get("/", (req, res) => {
  res.json({ message: "Homepage content route placeholder — implemented in stage 2" });
});

module.exports = router;
