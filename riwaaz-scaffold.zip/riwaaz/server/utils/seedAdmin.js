require("dotenv").config();
const mongoose = require("mongoose");
const Admin = require("../models/Admin");
const Settings = require("../models/Settings");
const HomepageContent = require("../models/HomepageContent");

const run = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  console.log("Connected to MongoDB for seeding...");

  const email = process.env.SEED_ADMIN_EMAIL || "admin@riwaaz.com";
  const password = process.env.SEED_ADMIN_PASSWORD || "change_me_immediately";

  const existing = await Admin.findOne({ email });
  if (existing) {
    console.log(`Admin already exists for ${email} — skipping creation.`);
  } else {
    await Admin.create({
      name: "Riwaaz Admin",
      email,
      password,
      role: "superadmin",
    });
    console.log("----------------------------------------------------");
    console.log("First admin account created:");
    console.log(`  Email:    ${email}`);
    console.log(`  Password: ${password}`);
    console.log("  Log in at /admin/login and change this password immediately.");
    console.log("----------------------------------------------------");
  }

  const settingsExists = await Settings.findOne();
  if (!settingsExists) {
    await Settings.create({ siteName: "Riwaaz" });
    console.log("Default Settings document created.");
  }

  const homepageExists = await HomepageContent.findOne();
  if (!homepageExists) {
    await HomepageContent.create({});
    console.log("Default HomepageContent document created.");
  }

  await mongoose.disconnect();
  console.log("Seeding complete.");
  process.exit(0);
};

run().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
